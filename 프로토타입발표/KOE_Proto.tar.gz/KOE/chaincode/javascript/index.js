/*
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const ProbProto = require('./lib/fabcar');

module.exports.ProbProto = ProbProto;
module.exports.contracts = [ ProbProto ];
